//
//  ViewController.h
//  Game1
//

//  Copyright (c) 2015 Hayden Lalljie. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <SpriteKit/SpriteKit.h>

@interface ViewController : UIViewController

@end
