//
//  Projectile.m
//  Game1
//
//  Created by student on 4/9/15.
//  Copyright (c) 2015 Hayden Lalljie. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Projectile.h"

@interface Projectile()


@end

@implementation Projectile

-(instancetype) init {
    
    self = [super init];
    
    return self;
}






@end
