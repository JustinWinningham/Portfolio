//
//  main.m
//  Game1
//
//  Created by Hayden Lalljie on 4/7/15.
//  Copyright (c) 2015 Hayden Lalljie. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "AppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
