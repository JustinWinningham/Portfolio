//
//  AppDelegate.h
//  Game1
//
//  Created by Hayden Lalljie on 4/7/15.
//  Copyright (c) 2015 Hayden Lalljie. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <SpriteKit/SpriteKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
