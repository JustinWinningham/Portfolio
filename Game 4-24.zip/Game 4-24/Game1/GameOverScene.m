//
//  GameOverScene.m
//  Game1
//
//  Created by Hayden Lalljie on 4/8/15.
//  Copyright (c) 2015 Hayden Lalljie. All rights reserved.
//

#import "GameOverScene.h"
#import "MyScene.h"
#import "AppDelegate.h"
#import "MainMenuViewController.h"
#import "ViewController.h"


@implementation GameOverScene

-(id)initWithSize:(CGSize)size Score:(int)Score {
    if (self = [super initWithSize:size]) {
        // 1
        self.backgroundColor = [SKColor colorWithRed:1.0 green:1.0 blue:1.0 alpha:1.0];
        // 2
        /*
        NSString * message;
        message = @"Game Over";
        // 3
        SKLabelNode *label = [SKLabelNode labelNodeWithFontNamed:@"Chalkduster"];
        label.text = message;
        label.fontSize = 40;
        label.fontColor = [SKColor blackColor];
        label.position = CGPointMake(self.size.width/2, self.size.height/2);
        [self addChild:label];
        */
        SKLabelNode *scorelabel = [SKLabelNode labelNodeWithFontNamed:@"Chalkduster"];
        scorelabel.text = [NSString stringWithFormat:@"Score: %i", Score];
        scorelabel.fontSize = 40;
        scorelabel.fontColor = [SKColor blackColor];
        scorelabel.position = CGPointMake(self.size.width/2, self.size.height*.6);
        
        
        
        [self addChild:scorelabel];
        [self addChild:[self mainLabel]];
        [self addChild:[self playAgain]];
        [self addChild:[self mainMenuBtn]];

        
        // 4
        /*
        [self runAction:
         [SKAction sequence:@[
                              [SKAction waitForDuration:3.0],
                              [SKAction runBlock:^{
             // 5
             SKTransition *reveal = [SKTransition flipHorizontalWithDuration:0.5];
             SKScene * myScene = [[MyScene alloc] initWithSize:self.size];
             [self.view presentScene:myScene transition: reveal];
         }]
                              ]]
         ];
         */
        
    }
    return self;
}

-(SKLabelNode *) mainLabel
{
    NSString * message;
    message = @"Game Over";
    SKLabelNode *label = [SKLabelNode labelNodeWithFontNamed:@"Chalkduster"];
    label.text = message;
    label.fontSize = 40;
    label.fontColor = [SKColor blackColor];
    label.position = CGPointMake(self.size.width/2, self.size.height/2);
    return label;
}

-(SKLabelNode *) playAgain
{
    NSString *message;
    message = @"Press button for menu";
    SKLabelNode *menulabel = [SKLabelNode labelNodeWithFontNamed:@"Chalkduster"];
    menulabel.text = message;
    menulabel.fontSize = 20;
    menulabel.fontColor = [SKColor blackColor];
    menulabel.position = CGPointMake(self.size.width/2, (self.size.height/3) * 2);
    return menulabel;
}

-(SKSpriteNode *) mainMenuBtn
{
    SKSpriteNode *mainMenu = [SKSpriteNode spriteNodeWithImageNamed:@"blueButton.png"];
    mainMenu.position = CGPointMake([UIScreen mainScreen].bounds.size.width/2, [UIScreen mainScreen].bounds.size.height/3);
    mainMenu.name = @"mainMenuButton";
    return mainMenu;
}

-(void) touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    UITouch *touch = [touches anyObject];
    CGPoint location = [touch locationInNode:self];
    SKNode *node = [self nodeAtPoint:location];
    
    if([node.name isEqualToString:@"mainMenuButton"])
    {
        AppDelegate *appdel = (AppDelegate *)[[UIApplication sharedApplication]delegate];
        UINavigationController *vc = (UINavigationController *)appdel.window.rootViewController;
        [vc.navigationController popToRootViewControllerAnimated:YES];
        //[self removeFromParent];
        //[[self.view.window.rootViewController navigationController] popToRootViewControllerAnimated:NO];
        //[self.view presentScene:nil];
    }
    else
    {
        [self runAction:
         [SKAction sequence:@[
                              [SKAction waitForDuration:.5],
                              [SKAction runBlock:^{
             // 5
             SKTransition *reveal = [SKTransition flipHorizontalWithDuration:0.5];
             SKScene * myScene = [[MyScene alloc] initWithSize:self.size];
             [self.view presentScene:myScene transition: reveal];
         }]
                              ]]
         ];

    }
}

@end
