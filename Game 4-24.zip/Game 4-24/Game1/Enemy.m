//
//  Enemy.m
//  Game1
//
//  Created by student on 4/9/15.
//  Copyright (c) 2015 Hayden Lalljie. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Enemy.h"

@interface Enemy()

@property (nonatomic) NSArray * enemyArray;
@property (nonatomic) NSString * greenEnemy;
@property (nonatomic) NSString * redEnemy;
@property (nonatomic) NSString * blueEnemy;

@end

@implementation Enemy

-(instancetype) initWithType:(NSString*)Color {
    
    self = [super init];
    
    self.greenEnemy = @"greenEnemy";
    self.redEnemy = @"redEnemy";
    self.blueEnemy = @"blueEnemy";
    
    if ([[Color lowercaseString]  isEqual: @"rand"] || [[Color lowercaseString] isEqual: @"random"])
        [self randomEnemy];
    else
        [self enemyWithColor:Color];
    
    return self;
}

-(NSArray *) enemyArray{
    if(! _enemyArray){
        _enemyArray = [[NSArray alloc] initWithObjects:_greenEnemy, _redEnemy, _blueEnemy, nil];
    }
    
    return _enemyArray;
}



-(Enemy *) randomEnemy{
    
    int randomNum = arc4random() % 3;
    
    NSString * randString = [self.enemyArray objectAtIndex:randomNum];
    
    
    Enemy * e = [Enemy spriteNodeWithImageNamed:randString];
    e.name = randString;
    
    
    return e;
}

-(Enemy *) enemyWithColor:(NSString*) Color{
    
    NSString *colorEnemy = [NSString stringWithFormat:@"%@Enemy", [Color lowercaseString]];
    Enemy * e = [Enemy spriteNodeWithImageNamed:colorEnemy];
    e.name = colorEnemy;
    
    
    
    return e;
}





@end
