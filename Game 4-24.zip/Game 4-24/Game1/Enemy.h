//
//  Enemy.h
//  Game1
//
//  Created by student on 4/9/15.
//  Copyright (c) 2015 Hayden Lalljie. All rights reserved.
//
#import <SpriteKit/SpriteKit.h>

@interface Enemy : SKSpriteNode

-(instancetype) initWithType:(NSString*)Color;
-(Enemy *) randomEnemy;
-(Enemy *) enemyWithColor:(NSString*) Color;
-(NSString *) greenEnemy;
-(NSString *) redEnemy;
-(NSString *) blueEnemy;

@end