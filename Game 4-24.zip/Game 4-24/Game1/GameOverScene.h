//
//  GameOverScene.h
//  Game1
//
//  Created by Hayden Lalljie on 4/8/15.
//  Copyright (c) 2015 Hayden Lalljie. All rights reserved.
//

#import <SpriteKit/SpriteKit.h>
#import "OverLordDataSource.h"

@interface GameOverScene : SKScene

-(id)initWithSize:(CGSize)size Score:(int) Score;

@end
