//
//  MyScene.m
//  Game1
//
//  Created by Hayden Lalljie on 4/7/15.
//  Copyright (c) 2015 Hayden Lalljie. All rights reserved.
//

#import "MyScene.h"
#import "GameOverScene.h"
#import "Enemy.h"
#import <UIKit/UIKit.h>
@import AVFoundation;

#define SK_DEGREES_TO_RADIANS(__ANGLE__) ((__ANGLE__) * 0.01745329252f) // PI / 180
#define ScoreHudName @"scoreHud"
// Collision Constants


static const uint32_t projectileCategory     =  0x1 << 0;
static const uint32_t monsterCategory        =  0x1 << 1;
static const uint32_t playerCategory         =  0x1 << 2;

//static const int EASY = 1.2;
//static const int MEDIUM = 1.5;
//static const int HARD = 1.75;
static const int INSANE = 2;
//static const int WHY/*?*/ = 10;

static const int difficulty = INSANE;

// 1
@interface MyScene () <SKPhysicsContactDelegate>

@property (nonatomic) SKSpriteNode * player;
@property (nonatomic) SKSpriteNode *triadButton;

@property (nonatomic) SKSpriteNode *pauseButton;

@property (nonatomic) NSTimeInterval lastSpawnTimeInterval;
@property (nonatomic) NSTimeInterval lastUpdateTimeInterval;

@property (nonatomic) int monstersDestroyed;
@property (nonatomic) int minDuration;
@property (nonatomic) int maxDuration;

@property (nonatomic) NSString * greenEnemy;
@property (nonatomic) NSString * redEnemy;
@property (nonatomic) NSString * blueEnemy;
@property (nonatomic) NSString * greenArrow;
@property (nonatomic) NSString * redSword;
@property (nonatomic) NSString * blueFire;


@end

// Vector Math
static inline CGPoint rwAdd(CGPoint a, CGPoint b) {
    return CGPointMake(a.x + b.x, a.y + b.y);
    
}
/*
static inline CGPoint rwSub(CGPoint a, CGPoint b) {
    return CGPointMake(a.x - b.x, a.y - b.y);
}
*/
static inline CGPoint rwMult(CGPoint a, float b) {
    return CGPointMake(a.x * b, a.y * b);
}

static inline float rwLength(CGPoint a) {
    return sqrtf(a.x * a.x + a.y * a.y);
}



// Makes a vector have a length of 1
static inline CGPoint rwNormalize(CGPoint a) {
    float length = rwLength(a);
    return CGPointMake(a.x / length, a.y / length);
}

int rotatation = 1;
float monsterSpawnRate = 3;

@implementation MyScene

- (SKSpriteNode *)triadButtonNode
{
    SKSpriteNode *triadButton = [SKSpriteNode spriteNodeWithImageNamed:@"triadButton"];
    triadButton.position = CGPointMake(25,self.frame.size.height/5);
    triadButton.name = @"triadButton";//how the node is identified later
    triadButton.zPosition = 1.0;
    triadButton.anchorPoint = CGPointMake(sqrt(3)*.2, .5);
    self.triadButton = triadButton;
    return triadButton;
}

-(id)initWithSize:(CGSize)size {
    if (self = [super initWithSize:size]) {
        
        self.minDuration = 12.0;
        self.maxDuration = 15.0;
        
        self.greenEnemy = @"greenEnemy";
        self.redEnemy = @"redEnemy";
        self.blueEnemy = @"blueEnemy";
        self.greenArrow = @"greenArrow";
        self.redSword = @"redSword";
        self.blueFire = @"blueFire";
        // 2
        NSLog(@"Size: %@", NSStringFromCGSize(size));
        
        // 3
        for (int i = 0; i < 2; i++) {
            SKSpriteNode * bg;
            if (i == 0)
                bg = [SKSpriteNode spriteNodeWithImageNamed:@"desert_background"];
            else
                bg = [SKSpriteNode spriteNodeWithImageNamed:@"desert_background_backwards"];
            bg.anchorPoint = CGPointZero;
            bg.position = CGPointMake(i * bg.size.width, self.frame.size.height/2);
            bg.name = @"desert_background";
            bg.zPosition = 1.5;
            [self addChild:bg];
        }
        //self.backgroundColor = [SKColor colorWithRed:1.0 green:1.0 blue:1.0 alpha:1.0];
        
        self.pauseButton = [SKSpriteNode spriteNodeWithImageNamed:@"pause"];
        self.pauseButton.position = CGPointMake(self.frame.size.width-25,self.frame.size.height-50);
        self.pauseButton.alpha = .5;
        self.pauseButton.name = @"pause";
        self.pauseButton.zPosition = 4.0;
        [self addChild:self.pauseButton];
        
        SKSpriteNode * bottom;
        bottom = [SKSpriteNode spriteNodeWithImageNamed:@"metal"];
        bottom.position = CGPointMake(0, 80);
        [self addChild:bottom];
        
        // 4
        self.player = [SKSpriteNode spriteNodeWithImageNamed:@"player"];
        self.player.position = CGPointMake(50, self.frame.size.height/2 + _player.size.height/2);
        self.player.physicsBody = [SKPhysicsBody bodyWithRectangleOfSize:self.player.size]; // 1
        self.player.physicsBody.dynamic = YES; // 2
        self.player.physicsBody.categoryBitMask = playerCategory; // 3
        self.player.physicsBody.contactTestBitMask = monsterCategory; // 4
        self.player.physicsBody.collisionBitMask = 0; // 5
        self.player.zPosition = 2.0;

        [self addChild:self.player];
        
        // Make Gravity Equal Zero
        self.physicsWorld.gravity = CGVectorMake(0,0);
        self.physicsWorld.contactDelegate = self;
        
        
        //Buttons
        // [self addChild: [self redButtonNode]];
        //[self addChild: [self greenButtonNode]];
        //[self addChild: [self blueButtonNode]];
        [self setupScore];
        self.triadButton = [self triadButtonNode];
        [self addChild: self.triadButton];
        
        
        
    }
    return self;
}

- (void)addMonsterWithColor: (NSString*) Color{
    
    // Create sprite
    //SKSpriteNode * monster = [SKSpriteNode spriteNodeWithImageNamed:@"greenEnemy"];
    Enemy *monster = [[Enemy alloc] initWithType:Color];
    
    if ([[Color lowercaseString]  isEqual: @"rand"] || [[Color lowercaseString] isEqual: @"random"])
        monster = [monster randomEnemy];
    else
        NSLog(@"Do Nothing" );
        //monster = [monster enemyWithColor:Color];
   
    
    
    // Monster Physics
    monster.physicsBody = [SKPhysicsBody bodyWithRectangleOfSize:monster.size]; // 1
    monster.physicsBody.dynamic = YES; // 2
    monster.physicsBody.categoryBitMask = monsterCategory; // 3
    monster.physicsBody.contactTestBitMask = projectileCategory; // 4
    monster.physicsBody.collisionBitMask = 0; // 5
    
    // Determine where to spawn the monster along the Y axis
    //int minY = monster.size.height / 2;
    //int maxY = self.frame.size.height - monster.size.height / 2;
    //int rangeY = maxY - minY;
    int actualY = self.frame.size.height/2 + monster.size.height/2;//(arc4random() % rangeY) + minY;
   
    // Create the monster slightly off-screen along the right edge,
    // and along a random position along the Y axis as calculated above
    monster.position = CGPointMake(self.frame.size.width + monster.size.width/2, actualY);
    [self addChild:monster];
    
    // Determine speed of the monster
    int minDuration = 10.0;
    int maxDuration = 12.0;
    int rangeDuration = maxDuration - minDuration;
    int actualDuration = (arc4random() % rangeDuration) + minDuration;
    
    //CGPoint move = [monster speed];
    
    // Create the actions
    SKAction * actionMove = [SKAction moveTo:CGPointMake(-monster.size.width/2, actualY) duration:actualDuration];
    SKAction * actionMoveDone = [SKAction removeFromParent];
    
    
    // Monster off screen is a game over
    //[monster runAction:[SKAction sequence:@[actionMove, loseAction, actionMoveDone]]];
    monster.zPosition = 2.0;

    [monster runAction:[SKAction sequence:@[actionMove, actionMoveDone]]];
    
}

- (void)updateWithTimeSinceLastUpdate:(CFTimeInterval)timeSinceLast {
    
    if(self.paused == NO){
    self.lastSpawnTimeInterval += timeSinceLast;
    if (self.lastSpawnTimeInterval > monsterSpawnRate) {
        self.lastSpawnTimeInterval = 0;
        [self addMonsterWithColor:@"raND"];
    }
    }
}

- (void)update:(NSTimeInterval)currentTime {
    // Handle time delta.
    // If we drop below 60fps, we still want everything to move the same distance.
    CFTimeInterval timeSinceLast = currentTime - self.lastUpdateTimeInterval;
    self.lastUpdateTimeInterval = currentTime;
    if (timeSinceLast > 1) { // more than a second since last update
        timeSinceLast = 1.0 / 60.0;
        self.lastUpdateTimeInterval = currentTime;
    }
    [self enumerateChildNodesWithName:@"desert_background" usingBlock: ^(SKNode *node, BOOL *stop) {
        SKSpriteNode *bg = (SKSpriteNode *) node;
        if(self.paused == NO){
            bg.position = CGPointMake(bg.position.x - 2, bg.position.y);}
        
        if (bg.position.x <= -bg.size.width) {
            bg.position = CGPointMake(bg.position.x + bg.size.width * 2, bg.position.y);
        }
    }];
    
    [self updateWithTimeSinceLastUpdate:timeSinceLast];
    
}

-(void)touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event {
    //bool red = NO;
    //bool blue = NO;
    //bool green = NO;
    
    UITouch * touch = [touches anyObject];
    CGPoint location = [touch locationInNode:self];
    SKNode *node = [self nodeAtPoint:location];
    NSString *pause = @"pause";
    if(node.name == pause)
    {
        [self pauseScreen];
    }
    //if fire button touched, bring the rain
    
    /*if ([node.name isEqualToString:@"redButton"]) {
        red = YES;
        [self runAction:[SKAction playSoundFileNamed:@"sword.mp3" waitForCompletion:NO]];
    }
    if ([node.name isEqualToString:@"blueButton"]) {
        blue = YES;
    }
    if ([node.name isEqualToString:@"greenButton"]) {
        green = YES;
    }
    if (red || green || blue)
    {
        // Audio
        
        
        // 1 - Choose one of the touches to work with
        
        //CGPoint location = [touch locationInNode:self];
        
        // 2 - Set up initial location of projectile
        SKSpriteNode * projectile;
        self.player.zPosition = 2.0;

        if (red == YES){
            projectile = [SKSpriteNode spriteNodeWithImageNamed:@"redSword"];
            projectile.name = @"redSword";
        }
        else if (blue == YES){
            projectile = [SKSpriteNode spriteNodeWithImageNamed:@"blueFire"];
            projectile.name = @"blueFire";
        }
        else if (green == YES){
            projectile = [SKSpriteNode spriteNodeWithImageNamed:@"greenArrow"];
            projectile.name = @"greenArrow";
        }
        projectile.position = self.player.position;
        
        //Projectile Physics
        projectile.physicsBody = [SKPhysicsBody bodyWithCircleOfRadius:projectile.size.width/2];
        projectile.physicsBody.dynamic = YES;
        projectile.physicsBody.categoryBitMask = projectileCategory;
        projectile.physicsBody.contactTestBitMask = monsterCategory;
        projectile.physicsBody.collisionBitMask = 0;
        projectile.physicsBody.usesPreciseCollisionDetection = YES;
        
        // 3- Determine offset of location to projectile
        //CGPoint offset = rwSub(location, projectile.position);
        
        // 4 - Bail out if you are shooting down or backwards
        //if (offset.x <= 0) return;
        
        // 5 - OK to add now - we've double checked position
        [self addChild:projectile];
        
        // 6 - Get the direction of where to shoot
        //CGPoint direction = rwNormalize(offset);
        CGPoint direction = rwNormalize(CGPointMake(projectile.position.y, 0));
        
        // 7 - Make it shoot far enough to be guaranteed off screen
        CGPoint shootAmount = rwMult(direction, 1000);
        
        // 8 - Add the shoot amount to the current position
        CGPoint realDest = rwAdd(shootAmount, projectile.position);
        
        // 9 - Create the actions
        float velocity = 100.0/1.0;
        float realMoveDuration = self.size.width / velocity;
        SKAction * actionMove = [SKAction moveTo:realDest duration:realMoveDuration];
        SKAction * actionMoveDone = [SKAction removeFromParent];
        [projectile runAction:[SKAction sequence:@[actionMove, actionMoveDone]]];
    }*/
    
}

-(void)killCheck:(SKSpriteNode *) projectile with:(SKSpriteNode *)monster{
    
    if([monster.name isEqualToString:(self.greenEnemy)]){
        if([projectile.name isEqualToString:( self.redSword)]){
            [monster removeFromParent];
            
            [self monsterDestroyed];
            //Update dictionary to record kill count.
        }
        
        if([projectile.name isEqualToString:(self.blueFire)]){
            //[self addMonsterWithColor:@"blue"];
            //Player projectile is destroyed, enemy's follows through to kill player.
            
        }
        if([projectile.name isEqualToString:( self.greenArrow)]){
            //[self addMonsterWithColor:@"green"];
            //Cancels out projectiles
        }
    }
    
    if([monster.name isEqualToString:( self.redEnemy)]){
        
        
        if([projectile.name isEqualToString:(self.blueFire)]){
            [monster removeFromParent];
            
            [self monsterDestroyed];
            
            //Update dictionary to record kill count.
        }
        
        if([projectile.name isEqualToString:( self.greenArrow)]){
            //[self addMonsterWithColor:@"green"];
            //Player projectile is destroyed, enemy's follows through to kill player.
            
        }
        if([projectile.name isEqualToString:( self.redSword)]){
            //[self addMonsterWithColor:@"red"];
            //Cancels out projectiles
        }
    }
    if([monster.name isEqualToString:( self.blueEnemy)]){
        
        
        if([projectile.name isEqualToString:( self.greenArrow)]){
            [monster removeFromParent];
            
            [self monsterDestroyed];
            
            //Update dictionary to record kill count.
        }
        
        if([projectile.name isEqualToString:( self.redSword)]){
            //[self addMonsterWithColor:@"red"];
            //Player projectile is destroyed, enemy's follows through to kill player.
            
        }
        if([projectile.name isEqualToString:(self.blueFire)]){
            //[self addMonsterWithColor:@"blue"];
            
            //Cancels out projectiles
        }
        
    }
    
    
}

-(void)monsterDestroyed
{
    
    [self runAction:[SKAction playSoundFileNamed:@"kill.mp3" waitForCompletion:NO]];
    
    self.monstersDestroyed++;
    
    SKLabelNode* score = (SKLabelNode*)[self childNodeWithName:ScoreHudName];
    score.text = [NSString stringWithFormat:@"Score: %04u", self.monstersDestroyed];
    
    if (self.monstersDestroyed % 10 == 0)
    {
        monsterSpawnRate /= difficulty;
        
        SKAction *soundAction = [SKAction playSoundFileNamed:@"drum.mp3" waitForCompletion:NO];
        SKAction *waitAction = [SKAction waitForDuration:.2];
        SKAction *sequence = [SKAction sequence:@[soundAction, waitAction]];
        
        SKAction *repeatAction = [SKAction repeatAction: sequence count:self.monstersDestroyed / 10];
        for (int i = 0; i < 100; i++) //quick fix for volume
        [self runAction:repeatAction];
    }
    
}

- (void)projectile:(SKSpriteNode *)projectile didCollideWithMonster:(SKSpriteNode *)monster {
    
    [projectile removeFromParent];
    
    [self killCheck:projectile with:monster];
    
    
    if(self.minDuration && self.maxDuration > 1){
        self.minDuration = self.minDuration * (3/4);
        self.maxDuration = self.maxDuration * (3/4);
    }
    
    /*if (self.monstersDestroyed > 50) {
        SKTransition *reveal = [SKTransition flipHorizontalWithDuration:0.5];
        SKScene * gameOverScene = [[GameOverScene alloc] initWithSize:self.size won:YES];
        [self.view presentScene:gameOverScene transition: reveal];
    }*/
}

- (void)gameOver {
    rotatation = 1;
    monsterSpawnRate = 3;
    SKTransition *reveal = [SKTransition flipHorizontalWithDuration:0.5];
    SKScene *gameOverScene = [[GameOverScene alloc] initWithSize: self.size Score:self.monstersDestroyed];
    [self.view presentScene:gameOverScene transition: reveal];
}


- (void)didBeginContact:(SKPhysicsContact *)contact
{
    // 1
    SKPhysicsBody *firstBody, *secondBody;
    
    if (contact.bodyA.categoryBitMask < contact.bodyB.categoryBitMask)
    {
        firstBody = contact.bodyA;
        secondBody = contact.bodyB;
    }
    else
    {
        firstBody = contact.bodyB;
        secondBody = contact.bodyA;
    }
    // 2
    if ((firstBody.categoryBitMask & projectileCategory) != 0 &&
        (secondBody.categoryBitMask & monsterCategory) != 0)
    {
        [self projectile:(SKSpriteNode *) firstBody.node didCollideWithMonster:(SKSpriteNode *) secondBody.node];
    }
    if ((firstBody.categoryBitMask & monsterCategory) != 0 &&
        (secondBody.categoryBitMask & playerCategory) != 0)
        [self gameOver];
}


/*- (SKSpriteNode *)redButtonNode
{
    SKSpriteNode *redButton = [SKSpriteNode spriteNodeWithImageNamed:@"redButton"];
    redButton.position = CGPointMake(self.frame.size.width/3,self.frame.size.height/5);
    redButton.name = @"redButton";//how the node is identified later
    redButton.zPosition = 1.0;
    return redButton;
}
- (SKSpriteNode *)greenButtonNode
{
    SKSpriteNode *greenButton = [SKSpriteNode spriteNodeWithImageNamed:@"greenButton"];
    greenButton.position = CGPointMake(self.frame.size.width/2,self.frame.size.height/3);
    greenButton.name = @"greenButton";//how the node is identified later
    greenButton.zPosition = 1.0;
    return greenButton;
}
- (SKSpriteNode *)blueButtonNode
{
    SKSpriteNode *blueButton = [SKSpriteNode spriteNodeWithImageNamed:@"blueButton"];
    blueButton.position = CGPointMake(self.frame.size.width/3 * 2,self.frame.size.height/5);
    blueButton.name = @"blueButton";//how the node is identified later
    blueButton.zPosition = 1.0;
    return blueButton;
}*/

- (void)didMoveToView:(SKView *)view
{
    UISwipeGestureRecognizer *upRecognizer = [[UISwipeGestureRecognizer alloc] initWithTarget:self action:@selector(handleSwipeUp:)];
    upRecognizer.direction = UISwipeGestureRecognizerDirectionUp;
    [[self view] addGestureRecognizer:upRecognizer];
    
    UISwipeGestureRecognizer *downRecognizer = [[UISwipeGestureRecognizer alloc] initWithTarget:self action:@selector(handleSwipeDown:)];
    downRecognizer.direction = UISwipeGestureRecognizerDirectionDown;
    [[self view] addGestureRecognizer:downRecognizer];
    
    UISwipeGestureRecognizer *rightRecognizer = [[UISwipeGestureRecognizer alloc] initWithTarget:self action:@selector(handleSwipeRight:)];
    rightRecognizer.direction = UISwipeGestureRecognizerDirectionRight;
    [[self view] addGestureRecognizer:rightRecognizer];
}
- (void)handleSwipeUp:(UISwipeGestureRecognizer *)sender
{
    if (sender.state == UIGestureRecognizerStateEnded)
    {
        CGPoint touchLocation = [sender locationInView:sender.view];
        touchLocation = [self convertPointFromView:touchLocation];
        //SKSpriteNode *touchedNode = (SKSpriteNode *)[self nodeAtPoint:touchLocation];
        if(self.paused == NO)
            [self rotateTriadUp];
        
    }
}
- (void)handleSwipeDown:(UISwipeGestureRecognizer *)sender
{
    if (sender.state == UIGestureRecognizerStateEnded)
    {
        CGPoint touchLocation = [sender locationInView:sender.view];
        touchLocation = [self convertPointFromView:touchLocation];
        //SKSpriteNode *touchedNode = (SKSpriteNode *)[self nodeAtPoint:touchLocation];
        if(self.paused == NO)
            [self rotateTriadDown];
        
    }
}

-(void) handleSwipeRight:(UISwipeGestureRecognizer *)sender{
    
    if (sender.state == UIGestureRecognizerStateEnded)
    {
        CGPoint touchLocation = [sender locationInView:sender.view];
        touchLocation = [self convertPointFromView:touchLocation];
        //SKSpriteNode *touchedNode = (SKSpriteNode *)[self nodeAtPoint:touchLocation];
        if(self.paused == NO)
            [self fireProjectile];
        
    }
}

-(void)fireProjectile{
    SKSpriteNode * projectile;
    SKSpriteNode * sudoProjectile;

    float sudoX = (self.triadButton.size.width/2);
    float sudoY = self.triadButton.position.y;// + (self.triadButton.size.height/2);

    if (rotatation % 3 == 0){
        projectile = [SKSpriteNode spriteNodeWithImageNamed:@"redSword"];
        projectile.name = @"redSword";
        
        sudoProjectile = [SKSpriteNode spriteNodeWithImageNamed:@"sudoRedSword"];
        sudoProjectile.name = @"sudoRedSword";
        
        sudoY = self.triadButton.position.y * 1.04;
        
        [self runAction:[SKAction playSoundFileNamed:@"sword.mp3" waitForCompletion:NO]];


    }
    else if (rotatation % 3 == 2){
        projectile = [SKSpriteNode spriteNodeWithImageNamed:@"blueFire"];
        projectile.name = @"blueFire";
        
        sudoProjectile = [SKSpriteNode spriteNodeWithImageNamed:@"sudoBlueFire"];
        sudoProjectile.name = @"sudoBlueFire";
        
        [self runAction:[SKAction playSoundFileNamed:@"fire.mp3" waitForCompletion:NO]];
    }
    else if (rotatation % 3 == 1){
        projectile = [SKSpriteNode spriteNodeWithImageNamed:@"greenArrow"];
        projectile.name = @"greenArrow";
        
        sudoProjectile = [SKSpriteNode spriteNodeWithImageNamed:@"sudoGreenArrow"];
        sudoProjectile.name = @"sudoGreenArrow";
        
        [self runAction:[SKAction playSoundFileNamed:@"arrow.mp3" waitForCompletion:NO]];
    }
    projectile.position = self.player.position;
    sudoProjectile.position = CGPointMake(sudoX, sudoY);
    
    projectile.zPosition = 2.0;
    sudoProjectile.zPosition = 2.0;
    
    //Projectile Physics
    projectile.physicsBody = [SKPhysicsBody bodyWithCircleOfRadius:projectile.size.width/2];
    projectile.physicsBody.dynamic = YES;
    projectile.physicsBody.categoryBitMask = projectileCategory;
    projectile.physicsBody.contactTestBitMask = monsterCategory;
    projectile.physicsBody.collisionBitMask = 0;
    projectile.physicsBody.usesPreciseCollisionDetection = YES;
    
    sudoProjectile.physicsBody = [SKPhysicsBody bodyWithCircleOfRadius:sudoProjectile.size.width/2];
    sudoProjectile.physicsBody.dynamic = YES;
    
    // 3- Determine offset of location to projectile
    //CGPoint offset = rwSub(location, projectile.position);
    
    // 4 - Bail out if you are shooting down or backwards
    //if (offset.x <= 0) return;
    
    // 5 - OK to add now - we've double checked position
    [self addChild:projectile];
    [self addChild:sudoProjectile];
    // 6 - Get the direction of where to shoot
    //CGPoint direction = rwNormalize(offset);
    CGPoint direction = rwNormalize(CGPointMake(projectile.position.y, 0));
    
    CGPoint sudoDirection = rwNormalize(CGPointMake(sudoY , 0));


    // 7 - Make it shoot far enough to be guaranteed off screen
    CGPoint shootAmount = rwMult(direction, 1000);
    CGPoint sudoShootAmount = rwMult(sudoDirection, 1000);
    
    // 8 - Add the shoot amount to the current position
    CGPoint realDest = rwAdd(shootAmount, projectile.position);
    CGPoint sudoRealDest = rwAdd(sudoShootAmount, sudoProjectile.position);
    

    
    // 9 - Create the actions
    float velocity = 100.0/1.0;
    float realMoveDuration = self.size.width / velocity;
    
    float sudoVelocity = 200.0/1.0;
    float sudoRealMoveDuration = self.size.width / sudoVelocity;
    
    SKAction * actionMove = [SKAction moveTo:realDest duration:realMoveDuration];
    SKAction * actionMoveDone = [SKAction removeFromParent];
    [projectile runAction:[SKAction sequence:@[actionMove, actionMoveDone]]];
    


    SKAction * sudoActionMove = [SKAction moveTo:sudoRealDest duration:sudoRealMoveDuration];
    SKAction * sudoActionMoveDone = [SKAction removeFromParent];
    [sudoProjectile runAction:[SKAction sequence:@[sudoActionMove, sudoActionMoveDone]]];

    
}

-(void) pauseScreen{
    self.paused = !self.paused;
    
    
    
    
}


-(void)rotateTriadUp
{
    
    //SKSpriteNode *self.triadButton = [self makeGreenBox:CGSizeMake(25, 25)];
    
    self.triadButton.anchorPoint = CGPointMake(sqrt(3)*.2,.5);
    //self.triadButton.position = CGPointMake(0,-50);
    //self.triadButton.zRotation = SK_DEGREES_TO_RADIANS(120*rotatation++);
    SKAction *rotation = [SKAction rotateByAngle: (SK_DEGREES_TO_RADIANS(120)) duration:.2];
    [self.triadButton runAction: rotation];
    rotatation ++;
    for (int i = 0; i < 2; i++)
        [self runAction:[SKAction playSoundFileNamed:@"switch.mp3" waitForCompletion:NO]];
    
    
    
    //self.triadButton.zRotation = (0.7871 * (3/2)); // About 90 degrees
    //[box2 addChild:[self.triadButtonNode]];
    // NSLog(@"blahalalala");
}
-(void)rotateTriadDown
{
    
    //SKSpriteNode *self.triadButton = [self makeGreenBox:CGSizeMake(25, 25)];
    
    self.triadButton.anchorPoint = CGPointMake(sqrt(3)*.2,.5);
    //self.triadButton.position = CGPointMake(0,-50);
    //M_PI/4.0 is 45 degrees, you can make duration different from 0 if you want to show the rotation, if it is 0 it will rotate instantly
    SKAction *rotation = [SKAction rotateByAngle: (SK_DEGREES_TO_RADIANS(-120)) duration:.2];
    rotatation +=2;
    //and just run the action
    [self.triadButton runAction: rotation];
    for (int i = 0; i < 2; i++)
        [self runAction:[SKAction playSoundFileNamed:@"switch.mp3" waitForCompletion:NO]];
    //self.triadButton.zRotation = SK_DEGREES_TO_RADIANS(120*rotatation--);
    
    //self.triadButton.zRotation = (0.7871 * (3/2)); // About 90 degrees
    //[box2 addChild:[self.triadButtonNode]];
    // NSLog(@"blahalalala");
}
-(void)setupScore {
    SKLabelNode* scoreLabel = [SKLabelNode labelNodeWithFontNamed:@"Courier"];
    //1
    scoreLabel.name = ScoreHudName;
    scoreLabel.fontSize = 25;
    //2
    scoreLabel.fontColor = [SKColor brownColor];
    scoreLabel.text = [NSString stringWithFormat:@"Score: %04u", 0];
    //3
    scoreLabel.position = CGPointMake(scoreLabel.frame.size.width * .6, self.size.height - (scoreLabel.frame.size.height * 2.5));
    scoreLabel.zPosition = 4;
    [self addChild:scoreLabel];
    

    //4
}




@end


/*
//
//  MyScene.m
//  Game1
//
//  Created by Hayden Lalljie on 4/7/15.
//  Copyright (c) 2015 Hayden Lalljie. All rights reserved.
//

#import "MyScene.h"
#import "GameOverScene.h"

// Collision Constants

static const uint32_t projectileCategory     =  0x1 << 0;
static const uint32_t monsterCategory        =  0x1 << 1;

// 1
@interface MyScene () <SKPhysicsContactDelegate>

@property (nonatomic) SKSpriteNode * player;

@property (nonatomic) NSTimeInterval lastSpawnTimeInterval;
@property (nonatomic) NSTimeInterval lastUpdateTimeInterval;

@property (nonatomic) int monstersDestroyed;

@end

// Vector Math
static inline CGPoint rwAdd(CGPoint a, CGPoint b) {
    return CGPointMake(a.x + b.x, a.y + b.y);
}

static inline CGPoint rwSub(CGPoint a, CGPoint b) {
    return CGPointMake(a.x - b.x, a.y - b.y);
}

static inline CGPoint rwMult(CGPoint a, float b) {
    return CGPointMake(a.x * b, a.y * b);
}

static inline float rwLength(CGPoint a) {
    return sqrtf(a.x * a.x + a.y * a.y);
}

// Makes a vector have a length of 1
static inline CGPoint rwNormalize(CGPoint a) {
    float length = rwLength(a);
    return CGPointMake(a.x / length, a.y / length);
}

@implementation MyScene

-(id)initWithSize:(CGSize)size {
    if (self = [super initWithSize:size]) {
        // 2
        NSLog(@"Size: %@", NSStringFromCGSize(size));
        
        // 3
        for (int i = 0; i < 2; i++) {
            SKSpriteNode * bg;
            if (i == 0)
                bg = [SKSpriteNode spriteNodeWithImageNamed:@"desert_background"];
            else
                bg = [SKSpriteNode spriteNodeWithImageNamed:@"desert_background_backwards"];
            bg.anchorPoint = CGPointZero;
            bg.position = CGPointMake(i * bg.size.width, self.frame.size.height/2);
            bg.name = @"desert_background";
            [self addChild:bg];
        }
        //self.backgroundColor = [SKColor colorWithRed:1.0 green:1.0 blue:1.0 alpha:1.0];
        SKSpriteNode *bottom;
        bottom = [SKSpriteNode spriteNodeWithImageNamed:@"player"];
        bottom.anchorPoint = CGPointZero;
        bottom.position = CGPointMake(0, -45);
        [self addChild:bottom];
        
        // 4
        self.player = [SKSpriteNode spriteNodeWithImageNamed:@"player"];
        self.player.position = CGPointMake(50, self.frame.size.height/2 + _player.size.height/2);
        [self addChild:self.player];
        
        // Make Gravity Equal Zero
        self.physicsWorld.gravity = CGVectorMake(0,0);
        self.physicsWorld.contactDelegate = self;
        
    }
    return self;
}

- (void)addMonster {
    
    // Create sprite
    SKSpriteNode * monster = [SKSpriteNode spriteNodeWithImageNamed:@"greenEnemy"];
    NSLog(@"SPAWING MONSTER");
    // Monster Physics
    monster.physicsBody = [SKPhysicsBody bodyWithRectangleOfSize:monster.size]; // 1
    monster.physicsBody.dynamic = YES; // 2
    monster.physicsBody.categoryBitMask = monsterCategory; // 3
    monster.physicsBody.contactTestBitMask = projectileCategory; // 4
    monster.physicsBody.collisionBitMask = 0; // 5
    
    // Determine where to spawn the monster along the Y axis
    int minY = monster.size.height / 2;
    int maxY = self.frame.size.height - monster.size.height / 2;
    int rangeY = maxY - minY;
    int actualY = self.frame.size.height/2 + monster.size.height/2;//(arc4random() % rangeY) + minY;
    
    // Create the monster slightly off-screen along the right edge,
    // and along a random position along the Y axis as calculated above
    monster.position = CGPointMake(self.frame.size.width + monster.size.width/2, actualY);
    [self addChild:monster];
    
    // Determine speed of the monster
    int minDuration = 1.0;
    int maxDuration = 7.0;
    int rangeDuration = maxDuration - minDuration;
    int actualDuration = (arc4random() % rangeDuration) + minDuration;
    
    // Create the actions
    SKAction * actionMove = [SKAction moveTo:CGPointMake(-monster.size.width/2, actualY) duration:actualDuration];
    SKAction * actionMoveDone = [SKAction removeFromParent];
    
    SKAction * loseAction = [SKAction runBlock:^{
        SKTransition *reveal = [SKTransition flipHorizontalWithDuration:0.5];
        SKScene * gameOverScene = [[GameOverScene alloc] initWithSize:self.size won:NO];
        [self.view presentScene:gameOverScene transition: reveal];
    }];
    
    // Monster off screen is a game over
    //[monster runAction:[SKAction sequence:@[actionMove, loseAction, actionMoveDone]]];
    [monster runAction:[SKAction sequence:@[actionMove, actionMoveDone]]];
    
}

- (void)updateWithTimeSinceLastUpdate:(CFTimeInterval)timeSinceLast {
    
    self.lastSpawnTimeInterval += timeSinceLast;
    if (self.lastSpawnTimeInterval > 1) {
        self.lastSpawnTimeInterval = 0;
        [self addMonster];
    }
}

- (void)update:(NSTimeInterval)currentTime {
    // Handle time delta.
    // If we drop below 60fps, we still want everything to move the same distance.
    CFTimeInterval timeSinceLast = currentTime - self.lastUpdateTimeInterval;
    self.lastUpdateTimeInterval = currentTime;
    if (timeSinceLast > 1) { // more than a second since last update
        timeSinceLast = 1.0 / 60.0;
        self.lastUpdateTimeInterval = currentTime;
    }
    [self enumerateChildNodesWithName:@"desert_background" usingBlock: ^(SKNode *node, BOOL *stop) {
        SKSpriteNode *bg = (SKSpriteNode *) node;
        bg.position = CGPointMake(bg.position.x - 5, bg.position.y);
        
        if (bg.position.x <= -bg.size.width) {
            bg.position = CGPointMake(bg.position.x + bg.size.width * 2, bg.position.y);
        }
    }];
    
    [self updateWithTimeSinceLastUpdate:timeSinceLast];
    
}

-(void)touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event {
    
    // Audio
    [self runAction:[SKAction playSoundFileNamed:@"pew-pew-lei.caf" waitForCompletion:NO]];
    
    // 1 - Choose one of the touches to work with
    UITouch * touch = [touches anyObject];
    CGPoint location = [touch locationInNode:self];
    
    // 2 - Set up initial location of projectile
    SKSpriteNode * projectile = [SKSpriteNode spriteNodeWithImageNamed:@"redSword"];
    projectile.position = self.player.position;
    
    //Projectile Physics
    projectile.physicsBody = [SKPhysicsBody bodyWithCircleOfRadius:projectile.size.width/2];
    projectile.physicsBody.dynamic = YES;
    projectile.physicsBody.categoryBitMask = projectileCategory;
    projectile.physicsBody.contactTestBitMask = monsterCategory;
    projectile.physicsBody.collisionBitMask = 0;
    projectile.physicsBody.usesPreciseCollisionDetection = YES;
    
    // 3- Determine offset of location to projectile
    CGPoint offset = rwSub(location, projectile.position);
    
    // 4 - Bail out if you are shooting down or backwards
    if (offset.x <= 0) return;
    
    // 5 - OK to add now - we've double checked position
    [self addChild:projectile];
    
    // 6 - Get the direction of where to shoot
    CGPoint direction = rwNormalize(offset);
    
    // 7 - Make it shoot far enough to be guaranteed off screen
    CGPoint shootAmount = rwMult(direction, 1000);
    
    // 8 - Add the shoot amount to the current position
    CGPoint realDest = rwAdd(shootAmount, projectile.position);
    
    // 9 - Create the actions
    float velocity = 100.0/1.0;
    float realMoveDuration = self.size.width / velocity;
    SKAction * actionMove = [SKAction moveTo:realDest duration:realMoveDuration];
    SKAction * actionMoveDone = [SKAction removeFromParent];
    [projectile runAction:[SKAction sequence:@[actionMove, actionMoveDone]]];
    
}

- (void)projectile:(SKSpriteNode *)projectile didCollideWithMonster:(SKSpriteNode *)monster {
    NSLog(@"Hit");
    [projectile removeFromParent];
    [monster removeFromParent];
    self.monstersDestroyed++;
    if (self.monstersDestroyed > 30) {
        SKTransition *reveal = [SKTransition flipHorizontalWithDuration:0.5];
        SKScene * gameOverScene = [[GameOverScene alloc] initWithSize:self.size won:YES];
        [self.view presentScene:gameOverScene transition: reveal];
    }
}

- (void)didBeginContact:(SKPhysicsContact *)contact
{
    // 1
    SKPhysicsBody *firstBody, *secondBody;
    
    if (contact.bodyA.categoryBitMask < contact.bodyB.categoryBitMask)
    {
        firstBody = contact.bodyA;
        secondBody = contact.bodyB;
    }
    else
    {
        firstBody = contact.bodyB;
        secondBody = contact.bodyA;
    }
    
    // 2
    if ((firstBody.categoryBitMask & projectileCategory) != 0 &&
        (secondBody.categoryBitMask & monsterCategory) != 0)
    {
        [self projectile:(SKSpriteNode *) firstBody.node didCollideWithMonster:(SKSpriteNode *) secondBody.node];
    }
}

@end
 */
