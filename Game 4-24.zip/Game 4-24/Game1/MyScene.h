//
//  MyScene.h
//  Game1
//

//  Copyright (c) 2015 Hayden Lalljie. All rights reserved.
//

#import <SpriteKit/SpriteKit.h>

@interface MyScene : SKScene

@end
