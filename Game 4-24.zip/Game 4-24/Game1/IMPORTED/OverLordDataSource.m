//
//  OverLordDataSource.m
//  CS470Project
//
//  Created by student on 4/6/15.
//  Copyright (c) 2015 TheGroup. All rights reserved.
//

#import "OverLordDataSource.h"

@interface OverLordDataSource ()

@property NSUInteger coins;
@property NSString *userName;
@property StatsBrain *Stats;

@end


@implementation OverLordDataSource

-(instancetype) initFirst
{
    NSLog(@"OVERLOARD FIRST INIT");
    _coins = 0;
    _userName = @"TEST";
    _Stats = [[StatsBrain alloc] initStats];
    
    return self;
}

-(instancetype) loadInstance
{
    NSLog(@"LOADING DATA FROM DISK?");
    NSData *decodedData = [NSData dataWithContentsOfFile: [OverLordDataSource getSavePath]];
    if(decodedData)
    {
        OverLordDataSource *gameData = [NSKeyedUnarchiver unarchiveObjectWithData:decodedData];
        return gameData;
    }
    return [[OverLordDataSource alloc] init];
}

-(instancetype)initWithCoder:(NSCoder *)aDecoder
{
    NSLog(@"Creating Master Data Source");
    self = [super init];
    if(!self)
        return nil;
    
    _coins = [aDecoder decodeIntegerForKey:@"coins"];
    _userName = [aDecoder decodeObjectForKey:@"userName"];
    _Stats = [aDecoder decodeObjectForKey:@"Stats"];
    
    return self;
}

-(void) encodeWithCoder:(NSCoder *)aCoder
{
    NSLog(@"Encoding Master Data Source");
    [aCoder encodeInteger:_coins forKey:@"coins"];
    [aCoder encodeObject:_userName forKey:@"userName"];
    [aCoder encodeObject:_Stats forKey:@"Stats"];
}

-(void)save
{
    NSLog(@"Saving...");
    NSData * encodedData = [NSKeyedArchiver archivedDataWithRootObject:self]; //this would be the function called in appdelegate when game is closed
    [encodedData writeToFile:[OverLordDataSource getSavePath] atomically:YES]; // may need to add more to this obviously, perhaps have calls to all lesser Data Sources to sync information with OverlordDataSource
    
    //http://www.raywenderlich.com/63235/how-to-save-your-game-data-tutorial-part-1-of-2
    // see this tutorial for more information
    NSLog(@"Saved!");
}

+(NSString *) getSavePath
{
    NSString *savePath = nil;
    if(!savePath)
    {
        savePath = [[NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) firstObject] stringByAppendingPathComponent:@"gamedata"];
    }
    return savePath;
}


-(StatsBrain *) getStats
{
    return _Stats;
}

-(void) UpdateStatsFromGame:(NSDictionary *)freshStats
{
    NSLog(@"WOOHOO IT WORKS!!!!");
}

@end
