//
//  MainMenuViewController.m
//  CS470Project
//
//  Created by student on 4/4/15.
//  Copyright (c) 2015 TheGroup. All rights reserved.
//

#import "MainMenuViewController.h"
@import AVFoundation;

@interface MainMenuViewController ()

@end

@implementation MainMenuViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.view.backgroundColor = [UIColor grayColor];
    
    CGFloat winWidth = [UIScreen mainScreen].bounds.size.width;
    CGFloat winHeight = [UIScreen mainScreen].bounds.size.height;
    CGFloat wideMargin = winWidth / 5;
    CGFloat highMargin = winHeight / 8;
    
    CGFloat buttonWide = winWidth - (2 * wideMargin);
    CGFloat buttonHigh = highMargin - 10;
    CGFloat buttonBuffer = 30;
    
    
    UIButton *startBttn = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    [startBttn addTarget:self action:@selector(startNewGame) forControlEvents:UIControlEventTouchUpInside];
    [startBttn setTitle:@"Play" forState:UIControlStateNormal];
    startBttn.backgroundColor = [UIColor lightGrayColor];
    
    UIButton *shopBttn = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    [shopBttn addTarget:self action:@selector(openShop) forControlEvents:UIControlEventTouchUpInside];
    [shopBttn setTitle:@"Shop" forState:UIControlStateNormal];
    shopBttn.backgroundColor = [UIColor lightGrayColor];
    
    UIButton *statsBttn = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    [statsBttn addTarget:self action:@selector(openStats) forControlEvents:UIControlEventTouchUpInside];
    [statsBttn setTitle:@"Stats" forState:UIControlStateNormal];
    statsBttn.backgroundColor = [UIColor lightGrayColor];
    
    UIButton *settingsBttn = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    [settingsBttn addTarget:self action:@selector(openSettings) forControlEvents:UIControlEventTouchUpInside];
    [settingsBttn setTitle:@"Settings" forState:UIControlStateNormal];
    settingsBttn.backgroundColor = [UIColor lightGrayColor];
    
    UIButton *helpBttn = [UIButton buttonWithType:UIButtonTypeCustom];
    [helpBttn addTarget:self action:@selector(displayTutorial) forControlEvents:UIControlEventTouchUpInside];
    [helpBttn setTitle:@"Help!" forState:UIControlStateNormal];
    helpBttn.backgroundColor = [UIColor lightGrayColor];
    [helpBttn.layer setBorderColor:[[UIColor whiteColor] CGColor]];
    helpBttn.layer.borderWidth = 2.0f;
    
    UIButton *ourSite = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    [ourSite addTarget:self action:@selector(openSite) forControlEvents:UIControlEventTouchUpInside];
    [ourSite setTitle:@"About Us" forState:UIControlStateNormal];
    ourSite.backgroundColor = [UIColor lightGrayColor];
    
    
    startBttn.frame = CGRectMake(wideMargin, highMargin, buttonWide, buttonHigh);
    shopBttn.frame = CGRectMake(wideMargin, highMargin * 2 + buttonBuffer, buttonWide, buttonHigh);
    statsBttn.frame = CGRectMake(wideMargin, highMargin * 3 + buttonBuffer, buttonWide, buttonHigh);
    settingsBttn.frame = CGRectMake(wideMargin, highMargin * 4 + buttonBuffer, buttonWide, buttonHigh);
    helpBttn.frame = CGRectMake(wideMargin, highMargin * 5 + buttonBuffer, buttonWide, buttonHigh);
    ourSite.frame  = CGRectMake(wideMargin, highMargin * 6 + buttonBuffer, buttonWide, buttonHigh / 2);
    
    
    [self.view addSubview:startBttn];
    [self.view addSubview:shopBttn];
    [self.view addSubview:statsBttn];
    [self.view addSubview:settingsBttn];
    [self.view addSubview:helpBttn];
    [self.view addSubview:ourSite];
    
    // Do any additional setup after loading the view.
}

-(void) startNewGame
{
    NSLog(@"Game Starting!");
    
    ViewController *v = [[ViewController alloc] init];
    [self.navigationController pushViewController:v animated:NO];
}

-(void) openShop
{
    NSLog(@"Opening Shop!");
    
    ShopTableViewController *shopPage = [[ShopTableViewController alloc] init];
    [self.navigationController pushViewController:shopPage animated:YES];
}

-(void) openStats
{
    NSLog(@"Opening Stats!");
    
    StatsBrain * stats = [[StatsBrain alloc] initStats];
    
    StatsTableViewController *statsPage = [[StatsTableViewController alloc] initWithData:stats];
    [self.navigationController pushViewController:statsPage animated:YES];
}

-(void) openSettings
{
    NSLog(@"Opening Settings!");
    
    SettingsViewController *settingsPage = [[SettingsViewController alloc] init];
    [self.navigationController pushViewController:settingsPage animated:YES];
}

-(void) displayTutorial
{
    NSLog(@"Displaying Tutorial!");
}

-(void) openSite
{
    NSLog(@"Opening our website!");
    NSURL *url = [NSURL URLWithString:@"http://www.sonoma.edu"];
    [[UIApplication sharedApplication] openURL:url];
    
}

-(void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)viewDidAppear:(BOOL)animated
{
    [self.navigationController setNavigationBarHidden:YES animated:YES];
    [super viewDidAppear:animated];
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/



@end
