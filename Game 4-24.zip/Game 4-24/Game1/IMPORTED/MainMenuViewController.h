//
//  MainMenuViewController.h
//  CS470Project
//
//  Created by student on 4/4/15.
//  Copyright (c) 2015 TheGroup. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <SpriteKit/SpriteKit.h>
#import "MyScene.h"
#import "StatsTableViewController.h"
#import "OverLordDataSource.h"
#import "SettingsViewController.h"
#import "StatsBrain.h"
#import "ShopDataSource.h"
#import "ShopTableViewController.h"
#import "ViewController.h"

@interface MainMenuViewController : UIViewController

@property (nonatomic) OverLordDataSource *masterData;

@end
