//
//  OverLordDataSource.h
//  CS470Project
//
//  Created by student on 4/6/15.
//  Copyright (c) 2015 TheGroup. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "ShopDataSource.h"
#import "StatsBrain.h"

@interface OverLordDataSource : NSObject <NSCoding>

-(instancetype) initFirst;
-(StatsBrain *) getStats;
-(void) UpdateStatsFromGame:(NSDictionary *)freshStats;

@end