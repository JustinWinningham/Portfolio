//
//  StatsBrain.m
//  CS470Project
//
//  Created by student on 4/4/15.
//  Copyright (c) 2015 TheGroup. All rights reserved.
//

#import "StatsBrain.h"

@interface StatsBrain ()

@property (nonatomic) NSMutableDictionary *Dictionary;
@property (nonatomic) NSMutableArray *StatsArray;

@end


@implementation StatsBrain


-(instancetype) initStats
{
    _Dictionary = [[NSMutableDictionary alloc] init];
    _StatsArray = [[NSMutableArray alloc] init];
    
    NSLog(@"Creating Stats");
    
    NSNumber *zero = [[NSNumber alloc] initWithInt:0];
    
    [self.Dictionary setValue:zero forKey:@"GamesPlayed"];
    [self.Dictionary setValue:zero forKey:@"ShotsFiredTotal"];
    [self.Dictionary setValue:zero forKey:@"HighScore"];
    [self.Dictionary setValue:zero forKey:@"RedKilled"];
    [self.Dictionary setValue:zero forKey:@"BlueKilled"];
    [self.Dictionary setValue:zero forKey:@"GreenKilled"];
    [self.Dictionary setValue:zero forKey:@"RedShot"];
    [self.Dictionary setValue:zero forKey:@"BlueShot"];
    [self.Dictionary setValue:zero forKey:@"GreenShot"];
    [self.Dictionary setValue:zero forKey:@"NumTimesPaused"];
    
    return self;
}


- (void) encodeWithCoder:(NSCoder *)aCoder
{
    NSLog(@"Saving Stats!");
    [self saveStats];
    
    if([aCoder allowsKeyedCoding])
    {
        [aCoder encodeObject:_Dictionary forKey:@"Dictionary"];
    }
    else
    {
        [aCoder encodeObject:_Dictionary];
    }
}

- (id) initWithCoder:(NSCoder *)aDecoder
{
    if(self = [super init])
    {
        NSLog(@"INITSTATSFROMCODER");
        if([aDecoder allowsKeyedCoding])
        {
            _Dictionary = [aDecoder decodeObjectForKey:@"Dictionary"];
        }
        else
        {
            _Dictionary = [aDecoder decodeObject];
        }
    }
    return self;
}

-(void) saveStats
{
    
}

-(NSInteger) numberOfStats
{
    return [self.Dictionary count];
}


-(void) printToLog
{
    
    NSLog(@"PRINTING ALL %@",@([self numberOfStats]));

    for(NSString *key in [self.Dictionary allKeys])
    {
        NSLog(@"Key: %@", key);
        NSLog(@"%@", [self.Dictionary objectForKey:key]);
    }
}


-(void) endGameUpdateStats: (NSDictionary *) dict
{
    
}

-(void) updateStat:(NSString *)statname withValue:(NSNumber *) val
{
    [self.Dictionary setValue: val forKey:statname];
}


@end
