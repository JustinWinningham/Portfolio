//
//  StatsTableViewController.h
//  CS470Project
//
//  Created by student on 4/4/15.
//  Copyright (c) 2015 TheGroup. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "StatsBrain.h"

@interface StatsTableViewController : UITableViewController

-(instancetype) initWithData:(StatsBrain *)Stats;

@end