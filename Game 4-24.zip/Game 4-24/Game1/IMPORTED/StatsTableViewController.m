//
//  StatsTableViewController.m
//  CS470Project
//
//  Created by student on 4/4/15.
//  Copyright (c) 2015 TheGroup. All rights reserved.
//

#import "StatsTableViewController.h"

@interface StatsTableViewController ()

@property (nonatomic) StatsBrain *stats;
@property (nonatomic) NSMutableArray *StatStrings;

@end

static NSString *CellIdentifier = @"Cell";

@implementation StatsTableViewController


-(instancetype) initWithData:(StatsBrain *)Stats // need to init stats before assignment!
{
    if(!Stats)
        _stats = [[StatsBrain alloc] initStats];
    else
        self.stats = Stats;
    
    return self;
}




- (void)viewDidLoad {
    [super viewDidLoad];
    
    NSLog(@"Loading Stats Page!");
    if(!self.stats)
        NSLog(@"Stats doesnt exist!");
    [self.navigationController setNavigationBarHidden:NO animated:YES];
    self.view.backgroundColor = [UIColor grayColor];
    self.tableView.separatorColor = [UIColor grayColor];
    
    // Uncomment the following line to preserve selection between presentations.
    // self.clearsSelectionOnViewWillAppear = NO;
    
    // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
    // self.navigationItem.rightBarButtonItem = self.editButtonItem;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    // Return the number of sections.
    
    NSInteger rows;
    rows = [self.stats numberOfStats];
    NSLog(@"rows: %ld", (long)rows);
    return rows;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    // Return the number of rows in the section.
    return 0;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier forIndexPath:indexPath];
    cell = [self statViewForIndex:[indexPath row] withTableViewCell:cell];
    // might need to create a simple class that contains a single stat to pass into this function to make the table view
    // controller behave. not sure though as of yet.
    
    // Configure the cell...
    
    return cell;
}

-(UITableViewCell *) statViewForIndex:(NSInteger) rowIndex withTableViewCell:(UITableViewCell *) cell
{
    
    return cell;
}



// Override to support conditional editing of the table view.
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the specified item to be editable.
    return NO;
}


/*
// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        // Delete the row from the data source
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
    } else if (editingStyle == UITableViewCellEditingStyleInsert) {
        // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
    }   
}
*/

/*
// Override to support rearranging the table view.
- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath {
}
*/

/*
// Override to support conditional rearranging of the table view.
- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the item to be re-orderable.
    return YES;
}
*/

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
