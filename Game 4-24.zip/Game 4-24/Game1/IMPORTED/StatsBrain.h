//
//  StatsBrain.h
//  CS470Project
//
//  Created by student on 4/4/15.
//  Copyright (c) 2015 TheGroup. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface StatsBrain : NSObject <NSCoding>

-(instancetype) initStats;
-(void) printToLog;
-(NSInteger) numberOfStats;
-(void) updateStat:(NSString *)statname withValue:(NSNumber *) val;
-(void) endGameUpdateStats: (NSDictionary *) dict;

@end
